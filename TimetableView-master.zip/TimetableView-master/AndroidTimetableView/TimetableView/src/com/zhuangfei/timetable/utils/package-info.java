/**
 * 该包存放一些全局的工具方法
 */
package com.zhuangfei.timetable.utils;