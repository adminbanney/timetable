package com.zhuangfei.timetable.listener;

import android.view.View;

/**
 * Created by Liu ZhuangFei on 2018/8/3.
 */

public class OnItemLongClickAdapter implements ISchedule.OnItemLongClickListener {
    @Override
    public void onLongClick(View v, int day, int start) {

    }
}
