package com.zhuangfei.timetable.listener;

/**
 * Created by Liu ZhuangFei on 2018/8/3.
 */

public class OnFlaglayoutClickAdapter implements ISchedule.OnFlaglayoutClickListener {
    @Override
    public void onFlaglayoutClick(int day, int start) {

    }
}
