/**
 * TimetableView是课表控件,主要是操作该对象进而完成对属性设置以及对视图的创建、更新
 */
package com.zhuangfei.timetable;