/**
 * 该包存放与Schedule有关的模型类
 */
package com.zhuangfei.timetable.model;