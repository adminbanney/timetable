package com.zhuangfei.timetable.listener;

/**
 *
 */

public class OnWeekChangedAdapter implements ISchedule.OnWeekChangedListener {
    @Override
    public void onWeekChanged(int curWeek) {

    }
}
